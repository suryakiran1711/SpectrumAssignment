package com.spectrum.assignment.service;

import java.util.Collection;
import java.util.List;

import com.spectrum.assignment.dto.PurchaseDetails;
import com.spectrum.assignment.dto.RewardPointResponse;

public interface RewardPointCalculatorService {
	public Collection<RewardPointResponse> calculateRewardPointsForEachTransaction(List<PurchaseDetails> purchaseDetailsList);
}
