package com.spectrum.assignment.service;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.spectrum.assignment.dto.CustomerIdAndMonth;
import com.spectrum.assignment.dto.PurchaseDetails;
import com.spectrum.assignment.dto.RewardPointResponse;
import com.spectrum.assignment.enums.Month;

@Service
public class RewardPointCalculatorServiceImpl implements RewardPointCalculatorService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RewardPointCalculatorServiceImpl.class);
	private static final BigDecimal TRANSACTION_AMOUNT_100 = new BigDecimal(100);
	private static final BigDecimal TRANSACTION_AMOUNT_50 = new BigDecimal(50);
	private static final int FIFTY_REWARD_POINTS = 50;
	
	@Value("${points.multiplier.after.50}")
	private int pointsMultiplierAfter50;
	
	@Value("${points.multiplier.after.100}")
	private int pointsMultiplierAfter100;
	
	
	@Override
	public Collection<RewardPointResponse> calculateRewardPointsForEachTransaction(List<PurchaseDetails> purchaseDetailsList) {
		LOGGER.info("RewardPointCalculatorServiceImpl.calculateRewardPointsForEachTransaction is called {}", purchaseDetailsList);
		
		
		Map<CustomerIdAndMonth, List<PurchaseDetails>> purchaseDetailsGroupedByCustomerIdAndMonth = purchaseDetailsList.stream()
		.collect(Collectors.groupingBy(
				purchaseDetails -> new CustomerIdAndMonth(purchaseDetails.getCustomerId(), 
						purchaseDetails.getMonth())));
		
		AtomicInteger monthlyRewardPoints = new AtomicInteger(0);
		Map<String, RewardPointResponse> categorizeCustomerAndTheirPoints = new HashMap<>();
		
		purchaseDetailsGroupedByCustomerIdAndMonth.forEach((customerIdAndMonth, purchaseDetailsListValue) -> {
			purchaseDetailsListValue.forEach(purchaseDetails -> {
				if (purchaseDetails.getTransactionAmount().compareTo(TRANSACTION_AMOUNT_100) == 1) {
					monthlyRewardPoints
					.addAndGet((FIFTY_REWARD_POINTS * pointsMultiplierAfter50) + purchaseDetails.getTransactionAmount()
					.subtract(TRANSACTION_AMOUNT_100).multiply(new BigDecimal(pointsMultiplierAfter100)).intValue());
				} else if (purchaseDetails.getTransactionAmount().compareTo(TRANSACTION_AMOUNT_50) == 1) {
					monthlyRewardPoints.addAndGet(purchaseDetails.getTransactionAmount()
							.subtract(TRANSACTION_AMOUNT_50).multiply(new BigDecimal(pointsMultiplierAfter50)).intValue());
				}
			});
			
			
			if (null == categorizeCustomerAndTheirPoints.get(customerIdAndMonth.getCustomerId())) {
				Map<Month, Integer> monthNameAndRewardPoints = new HashMap<>();
				monthNameAndRewardPoints.put(customerIdAndMonth.getMonth(), monthlyRewardPoints.get());
				RewardPointResponse rewardPointResponse = new RewardPointResponse(customerIdAndMonth.getCustomerId(), monthNameAndRewardPoints, monthlyRewardPoints.get());
				categorizeCustomerAndTheirPoints.put(customerIdAndMonth.getCustomerId(), rewardPointResponse);
			} else {
				RewardPointResponse rewardPointResponse = categorizeCustomerAndTheirPoints.get(customerIdAndMonth.getCustomerId());
				rewardPointResponse.getMonthlyEarnedPoints().put(customerIdAndMonth.getMonth(), monthlyRewardPoints.get());
				rewardPointResponse.setTotalEarnedPoints(rewardPointResponse.getTotalEarnedPoints() + monthlyRewardPoints.get());
			}
			
			monthlyRewardPoints.set(0);
		});
		
		return categorizeCustomerAndTheirPoints.values();
	}
	
}

