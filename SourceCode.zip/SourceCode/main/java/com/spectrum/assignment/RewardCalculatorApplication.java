package com.spectrum.assignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RewardCalculatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(RewardCalculatorApplication.class, args);
	}

}


/*


Test Case : 1
-------------
[
    {
        "customerId" : "123",
        "transactionAmount" : 100,
         "month": "JANUARY"
    },
    {
        "customerId" : "123",
        "transactionAmount" : 75,
         "month": "FEBRUARY"
    },
    {
        "customerId" : "123",
        "transactionAmount" : 1.2,
         "month": "JANUARY"
    },
    {
        "customerId" : "123",
        "transactionAmount" : 100,
         "month": "JANUARY"
    }
]

Test Case : 2
-------------
[
    {
        "customerId" : "123",
        "transactionAmount" : 1.5,
         "month": "JANUARY"
    },
    {
        "customerId" : "123",
        "transactionAmount" : 1.2,
         "month": "FEBRUARY"
    },
    {
        "customerId" : "123",
        "transactionAmount" : 1.2,
         "month": "JANUARY"
    },
    {
        "customerId" : "123",
        "transactionAmount" : 1.7,
         "month": "JANUARY"
    }
]

Test Case : 3
-------------
[
    {
        "customerId" : "123",
        "transactionAmount" : 100,
         "month": "JANUARY"
    },
    {
        "customerId" : "123",
        "transactionAmount" : 75,
         "month": "FEBRUARY"
    },
    {
        "customerId" : "123",
        "transactionAmount" : 104,
         "month": "JANUARY"
    },
    {
        "customerId" : "123",
        "transactionAmount" : 100,
         "month": "JANUARY"
    }
]

Test Case : 4
-------------
[
    {
        "customerId" : "123",
        "transactionAmount" : 100,
         "month": "JANUARY"
    },
    {
        "customerId" : "123",
        "transactionAmount" : 75,
         "month": "FEBRUARY"
    },
    {
        "customerId" : "123",
        "transactionAmount" : 104,
         "month": "JANUARY"
    },
    {
        "customerId" : "1234",
        "transactionAmount" : 150,
         "month": "JANUARY"
    },
    {
        "customerId" : "1234",
        "transactionAmount" : 125,
         "month": "JANUARY"
    },
    {
        "customerId" : "1234",
        "transactionAmount" : 85,
         "month": "FEBRUARY"
    },
    {
        "customerId" : "1234",
        "transactionAmount" : 108,
         "month": "JANUARY"
    },
    {
        "customerId" : "1234",
        "transactionAmount" : 100,
         "month": "JANUARY"
    }
]




*/