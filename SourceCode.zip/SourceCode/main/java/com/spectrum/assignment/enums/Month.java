package com.spectrum.assignment.enums;

import java.util.Arrays;

import com.spectrum.assignment.exception.InvalidMonthException;

public enum Month {
	JANUARY("JAN"),
	FEBRUARY("FEB"),
	MARCH("MAR"),
	APRIL("APR"),
	MAY("MAY"),
	JUNE("JUN"),
	JULY("JUL"),
	AUGUST("AUG"),
	SEPTEMBER("SEP"),
	OCTOBER("OCT"),
	NOVEMBER("NOV"),
	DECEMBER("DEC");
	
	private String month;
	
	public String getMonth() {
		return this.month;
	}
	
	private Month(String month) {
		this.month = month;
	}
	
	public static Month from(String month) {
		if (null == month || month.trim().length() == 0) {
			throw new InvalidMonthException("Month " + month + " is not valid");
		}
		
		return Arrays.stream(Month.values())
		.filter(constant -> constant.getMonth().equalsIgnoreCase(month)).findFirst()
		.orElseThrow(() -> new InvalidMonthException("Month " + month + " is not valid"));
	}
}
