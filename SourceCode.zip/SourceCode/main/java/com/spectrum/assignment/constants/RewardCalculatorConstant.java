package com.spectrum.assignment.constants;

public interface RewardCalculatorConstant {
	public static final String SUCCESS = "Success";
}
