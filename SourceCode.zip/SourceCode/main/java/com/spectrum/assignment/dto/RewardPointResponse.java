package com.spectrum.assignment.dto;

import java.io.Serializable;
import java.util.Map;

import com.spectrum.assignment.enums.Month;

public class RewardPointResponse implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String customerId;
	private Map<Month, Integer> monthlyEarnedPoints;
	private Integer totalEarnedPoints;
	
	public RewardPointResponse(String customerId, Map<Month, Integer> monthlyEarnedPoints, Integer totalEarnedPoints) {
		this.customerId = customerId;
		this.monthlyEarnedPoints = monthlyEarnedPoints;
		this.totalEarnedPoints = totalEarnedPoints;
	}
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public Map<Month, Integer> getMonthlyEarnedPoints() {
		return monthlyEarnedPoints;
	}
	public void setMonthlyEarnedPoints(Map<Month, Integer> monthlyEarnedPoints) {
		this.monthlyEarnedPoints = monthlyEarnedPoints;
	}
	public Integer getTotalEarnedPoints() {
		return totalEarnedPoints;
	}
	public void setTotalEarnedPoints(Integer totalEarnedPoints) {
		this.totalEarnedPoints = totalEarnedPoints;
	}
	
}
