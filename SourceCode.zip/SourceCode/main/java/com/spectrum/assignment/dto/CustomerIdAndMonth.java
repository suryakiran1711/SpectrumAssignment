package com.spectrum.assignment.dto;

import java.io.Serializable;
import java.util.Objects;

import com.spectrum.assignment.enums.Month;

public class CustomerIdAndMonth implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String customerId;
	private Month month;
	
	public CustomerIdAndMonth(String customerId, Month month) {
		this.customerId = customerId;
		this.month = month;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Month getMonth() {
		return month;
	}

	public void setMonth(Month month) {
		this.month = month;
	}

	@Override
	public int hashCode() {
		return Objects.hash(customerId, month);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerIdAndMonth other = (CustomerIdAndMonth) obj;
		return Objects.equals(customerId, other.customerId) && month == other.month;
	}

	@Override
	public String toString() {
		return "CustomerIdAndMonth [customerId=" + customerId + ", month=" + month + "]";
	}

}
