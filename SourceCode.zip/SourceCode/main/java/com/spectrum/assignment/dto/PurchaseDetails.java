package com.spectrum.assignment.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.spectrum.assignment.enums.Month;

public class PurchaseDetails implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String customerId;
	private BigDecimal transactionAmount;
	private Month month;
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public BigDecimal getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(BigDecimal transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public Month getMonth() {
		return month;
	}
	public void setMonth(Month month) {
		this.month = month;
	}

}