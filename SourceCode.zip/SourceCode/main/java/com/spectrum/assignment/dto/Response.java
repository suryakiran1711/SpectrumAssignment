package com.spectrum.assignment.dto;

import java.io.Serializable;

public class Response implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String message;
	private int code;
	private boolean isError;
	private Object response;
	
	public Response(String message, int code, boolean isError, Object response) {
		this.message = message;
		this.code = code;
		this.isError = isError;
		this.response = response;
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public boolean isError() {
		return isError;
	}
	public void setError(boolean isError) {
		this.isError = isError;
	}
	public Object getResponse() {
		return response;
	}
	public void setResponse(Object response) {
		this.response = response;
	}

}
