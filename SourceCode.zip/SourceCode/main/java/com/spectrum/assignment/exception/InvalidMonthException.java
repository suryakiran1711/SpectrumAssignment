package com.spectrum.assignment.exception;

public class InvalidMonthException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
	public InvalidMonthException(String message) {
		super(message);
	}
	
}
