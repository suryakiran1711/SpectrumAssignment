package com.spectrum.assignment.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.spectrum.assignment.dto.Response;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(ApplicationException.class)
	public ResponseEntity<Response> handleApplicationException(ApplicationException applicationException) {
		return buildResponseEntity(applicationException.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.TRUE);
	}
	
	@ExceptionHandler(InvalidMonthException.class)
	public ResponseEntity<Response> handleInvalidMonthException(InvalidMonthException invalidMonthException) {
		return buildResponseEntity(invalidMonthException.getMessage(), HttpStatus.BAD_REQUEST.value(), Boolean.TRUE);
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<Response> handleException(Exception exception) {
		return buildResponseEntity(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.TRUE);
	}
	
	private ResponseEntity<Response> buildResponseEntity(String message, int code, boolean isError) {
		Response errorResponse = new Response(message, code, isError, null);
		return new ResponseEntity<Response>(errorResponse, HttpStatus.valueOf(code));
	}

}
