package com.spectrum.assignment.controller;

import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spectrum.assignment.constants.RewardCalculatorConstant;
import com.spectrum.assignment.dto.PurchaseDetails;
import com.spectrum.assignment.dto.Response;
import com.spectrum.assignment.dto.RewardPointResponse;
import com.spectrum.assignment.exception.InvalidInputException;
import com.spectrum.assignment.service.RewardPointCalculatorService;

@RestController
@RequestMapping("/api")
public class RewardPointCalculatorController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RewardPointCalculatorController.class);
	
	@Autowired
	private RewardPointCalculatorService rewardPointCalculatorService;
	
	@PostMapping("/rewards/point/caluclator")
	public ResponseEntity<Response> calculateRewardPointsForEachTransaction(@RequestBody List<PurchaseDetails> purchaseDetailsList) {
		LOGGER.info("RewardPointCalculatorController.calculateRewardPointsForEachTransaction is called with {}", purchaseDetailsList);
		
		if (null == purchaseDetailsList || purchaseDetailsList.size() == 0) {
			throw new InvalidInputException("purchaseDetailsList is null or empty");
		}
		
		Collection<RewardPointResponse> response = rewardPointCalculatorService.calculateRewardPointsForEachTransaction(purchaseDetailsList);
		return new ResponseEntity<Response>(new Response(RewardCalculatorConstant.SUCCESS, HttpStatus.OK.value(), Boolean.FALSE, response), HttpStatus.OK);
	}
}
